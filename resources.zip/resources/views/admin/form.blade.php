@extends('layouts.admin')

@section('content')
@php($page_title ="add")
 <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    <div class="content">
      <ul class="breadcrumb">
        <li>
          <p>Dashboard</p>
        </li>
        <li><a href="#" class="active"><?= ($page_title == 'add')?'Add New':'Edit'; ?> <?= (isset($page_heading))?$page_heading:''; ?></a> </li>
      </ul>
      <div class="page-title"> <i class="icon-custom-left"></i>
        <h3><?= ($page_title == 'add')?'Add New':'Edit'; ?> - <span class="semi-bold"><?= (isset($page_heading))?$page_heading:''; ?></span></h3>
      </div>
    <!-- BEGIN BASIC FORM ELEMENTS-->
        <div class="row">
            <div class="col-md-12">
              <div class="grid simple">
                <div class="grid-title no-border">
                  <h4><?= ($page_title == 'add')?'Add New':'Edit'; ?> <?= (isset($page_heading))?$page_heading:''; ?> <span class="semi-bold">Form</span></h4>
                </div>
                <div class="grid-body no-border"> <br>
                  <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-8">
                      <form class="ajaxForm validate" action="" method="post" enctype="multipart/form-data">
                        
                        <div class="form-group">
                          <label class="form-label">Title <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "Pakistan Tour"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_title" class="form-control" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Short Description <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "Mona Lisa Portrait"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <textarea name="tour_short_description" class="form-control" placeholder="Enter Tour Short Description" ><?= @$data['tour_short_description']; ?></textarea>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Short Description Inner <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <textarea name="tour_short_description_inner" id="myeditor2" class="form-control" placeholder="Enter Tour Short Description Inner" ><?= @$data['tour_short_description_inner']; ?></textarea>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Description <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <textarea name="tour_description" id="myeditor" class="form-control" placeholder="Enter Tour Description" ><?= @$data['tour_description']; ?></textarea>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="form-label">Vouchar Description <span class="red_asterisk">* </span></label>
                          <span class="help">(No bullets or special charcacters.)</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <textarea name="tour_vouchar_description" id="myeditor3" class="form-control" placeholder="Enter Tour Vouchar Description" ><?= @$data['tour_vouchar_description']; ?></textarea>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Category <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <select class="select2" style="width:100%" name="category_id" id="category_id">
                              <option value="" selected="selected" disabled="">- Select Category -</option>
                              <?php
                              if (isset($categorydata) && $categorydata != null) {
                                foreach ($categorydata as $k => $v) {
                                  if(@$data['category_id'] != @$v['category_id']){
                              ?>
                                <option value="<?= $v['category_id']; ?>" <?= (@$data['category_id'] == @$v['category_id'])?'selected':''; ?>> <?= $v['category_name']; ?></option>
                              <?php
                                  }
                                  else{
                                    ?>
                                <option selected value="<?= $v['category_id']; ?>" <?= (@$data['category_id'] == @$v['category_id'])?'selected':''; ?>> <?= $v['category_name']; ?></option>
                              <?php

                                  }
                                }
                              }
                              ?>
                              
                            </select>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Image</label>
                          <div id="preview"></div>
                          <div class="controls">
                            <?php
                            if (isset($data['tour_id']) && @$data['tour_id'] != null) {
                                $appendedFiles2 = array();
                                $file_path = public_path().$image_upload_dir.'/'.@$data['tour_image'];
                                  if (!is_dir($file_path) && file_exists($file_path)) {
                                    // $current_img = MyCdnUrlImage($image_upload_dir."/".$data['image']);
                                    @$file_details = getimagesize(MyCdnUrlImage($image_upload_dir."/".@$data['tour_image']));
                                    $appendedFiles2[] = array(
                                      "name" => @$data['tour_image'],
                                      "type" => $file_details['mime'],
                                      "size" => filesize($file_path),
                                      "file" => MyCdnUrlImage($image_upload_dir."/". @$data['tour_image']),
                                      "data" => array(
                                        "url" => MyCdnUrlImage($image_upload_dir."/". @$data['tour_image']),
                                        "image_file_id" => $data['tour_id']
                                      )
                                    );
                                  }
                                $appendedFiles2 = json_encode($appendedFiles2);
                            }
                            ?>
                            <input type="file" id="fileUploader2" name="fileUploader2" class="form-control" data-fileuploader-files='<?php echo @$appendedFiles2;?>' accept="image/*">
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="form-label">Voucher Image</label>
                          <span class="help">(Make sure the image is of width = 600 and height= 180)</span>
                          <div id="preview"></div>
                          <div class="controls">
                            <?php
                            if (isset($data['tour_id']) && @$data['tour_id'] != null) {
                                $appendedFiles3 = array();
                                $file_path = public_path().$image_upload_dir.'/'.@$data['tour_voucher_image'];
                                  if (!is_dir($file_path) && file_exists($file_path)) {
                                    // $current_img = MyCdnUrlImage($image_upload_dir."/".$data['image']);
                                    @$file_details = getimagesize(MyCdnUrlImage($image_upload_dir."/".@$data['tour_voucher_image']));
                                    $appendedFiles3[] = array(
                                      "name" => @$data['tour_voucher_image'],
                                      "type" => $file_details['mime'],
                                      "size" => filesize($file_path),
                                      "file" => MyCdnUrlImage($image_upload_dir."/". @$data['tour_voucher_image']),
                                      "data" => array(
                                        "url" => MyCdnUrlImage($image_upload_dir."/". @$data['tour_voucher_image']),
                                        "image_file_id" => $data['tour_id']
                                      )
                                    );
                                  }
                                $appendedFiles3 = json_encode($appendedFiles3);
                            }
                            ?>
                            <input type="file" id="fileUploader3"  name="fileUploader3" class="form-control" data-fileuploader-files='<?php echo @$appendedFiles3;?>' accept="image/*">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Duration <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_duration" class="form-control" placeholder="Enter Duration" value="<?= @$data['tour_duration']; ?>">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="label-signin-mystyle">Dinner <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "If Yes Enter Options Like Dinner (Veg & Non veg), Else None"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            
                            <select class="form-control input-signin-mystyle select2" id="tour_dinner" name="tour_dinner">
                              <option value="" selected="selected" disabled="">- Select Status -</option>
                              <option value="1" <?= (@$data['tour_dinner'] == 1)?'selected':''; ?>>Dinner (Veg & Non Veg)</option>
                              <option value="0" <?= (@$data['tour_dinner'] == 0)?'selected':''; ?>>No Dinner</option>
                            </select>
                            <!--<input type="text" name="tour_dinner" class="form-control" placeholder="Enter Dinner " value="<?= @$data['tour_dinner']; ?>">-->
                          </div>
                        </div>

                        <div class="form-group">
                          <label for="nationality" class="label-signin-mystyle">
                            Pick Up & Drop <span class="red_asterisk">*</span>
                          </label>
                          <span class="help">e.g. "Yes, No"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <select class="form-control input-signin-mystyle select2" id="tour_pick_up" name="tour_pick_up">
                              <option value="" selected="selected" disabled="">- Select Status -</option>
                              <option value="1" <?= (@$data['tour_pick_up'] == 1)?'selected':''; ?>>Yes</option>
                              <option value="0" <?= (@$data['tour_pick_up'] == 0)?'selected':''; ?>>No</option>
                            </select>
                          </div>
                        </div>

                        <!-- <div class="form-group">
                          <label class="form-label">Pick Up Time </label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="time" name="tour_pickup_time" class="form-control" placeholder="Enter Pickup Time " value="<?= @$data['tour_pickup_time']; ?>">
                          </div>
                        </div> -->
                        
                        <div class="form-group">
                          <label class="form-label">Pick Up Time </label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_pickup_time" class="clockpicker form-control" placeholder="Enter Pickup Time " value="<?= @$data['tour_pickup_time']; ?>">
                          </div>
                        </div>

                        <div class="form-group">
                            <label for="tour_time" class="label-signin-mystyle">
                              Tour Time <span class="red_asterisk">*</span>
                            </label>
                            <span class="help">e.g. "Any , Morning , Evening, Overnight"</span>
                            <div class="input-with-icon right controls">
                              <i class=""></i>
                              <select class="form-control input-signin-mystyle select2" id="tour_time" name="tour_time">
                                <option value="" selected="selected" disabled="">- Select Tour Time -</option>
                               
                              </select>
                            </div>
                          </div>

                        <div class="form-group">
                          <label for="nationality" class="label-signin-mystyle">
                            Tour Live Guide <span class="red_asterisk">*</span>
                          </label>
                          <span class="help">e.g. "Yes, No"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <select class="form-control input-signin-mystyle select2" id="tour_live_guide" name="tour_live_guide">
                              <option value="" selected="selected" disabled="">- Select Live Guide Status -</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                            </select>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Exclusive Price Per Car <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "Per Car Price"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_exclusive_price" class="form-control txtboxToFilter" placeholder="Enter Price Per Person" value="">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Shared Adult Price Per Person <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "Adult Price Per Person Exclusive Price"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_shared_price_per_person" class="form-control txtboxToFilter" placeholder="Enter Price Per Person" >
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Shared Child Price Per Person <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "Child Price Per Person Exclusive Price"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_child_shared_price_per_person" class="form-control txtboxToFilter" placeholder="Enter Price Per Person" value="">
                          </div>
                        </div>

                        
                        

                        <div class="form-group">
                          <label class="form-label">Slider Images </label>
                          <input type="file" class="form-control" name="fileToUpload" multiple id="fileUploader" data-fileuploader-files=''>
                        </div>

                        <div class="form-group">
                          <label class="form-label">SEO URL <span class="red_asterisk">*</span></label>
                          <span class="help">e.g. "Do not use spaces, instead replace spaces with - and make sure the SEO URL is globally unique."</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="tour_seo_url" class="form-control" placeholder="Enter SEO URL" value="">
                          </div>
                        </div>

                        <div class="form-group">
                          <label for="nationality" class="label-signin-mystyle">
                            Special Offers
                           <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <select class="form-control input-signin-mystyle select2" id="speical_offer_type" name="speical_offer_type">
                              <option value="" selected="selected" disabled="">- Select Special Offers -</option>
                              <option value="1">Yes</option>
                              <option value="0">No</option>
                            </select>
                          </div>
                        </div>

                        <div class="myTourDiscount" style="">
                          <div class="form-group">
                            <label class="form-label">Discount % <span class="red_asterisk">*</span></label>
                            <span class="help">e.g. "25 %"</span>
                            <div class="input-with-icon right controls">
                              <i class=""></i>
                              <input type="text" name="discount_percentage" maxlength="2" class="txtboxToFilter form-control" placeholder="Enter Discount Percentage In Numbers" value="">
                            </div>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <h3><b>Add Ons</b></h3>
                          <div class="amenities_field">
                            <div class="row form-row">
                              <div class="col-md-12">
                                <button type="button" class="btn btn-primary pull-right amenities_field_button">Add More</button>
                              </div>
                            </div>
                            
                              <div class="row form-row">
                                <div class="col-md-6">
                                    <div class="form-row">
                                      <label class="loc_name">Add On Title <span class="red_asterisk">*</span></label>
                                      <div class="input-with-icon right controls"> <i class=""></i>
                                      <input type="text" id="loc_names" required name="add_on_title[]" class="form-control" placeholder="Enter Add On Title" value=""> </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-row">
                                      <label class="location">Add On Adult Price Per Person <span class="red_asterisk">*</span></label>
                                      <div class="input-with-icon right controls"> <i class=""></i>
                                      <input required type="number" id="locations" name="add_on_adult_price_per_person[]" class="form-control txtboxToFilter" placeholder="Enter Add On Adult Price Per Person" value=""> </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-row">
                                      <label class="ad_phone">Add On Adult Child Price Per Person <span class="red_asterisk">*</span></label>
                                      <div class="input-with-icon right controls"> <i class=""></i>
                                          <input type="number" id="ad_phones" required name="add_on_child_price_per_person[]" class="form-control txtboxToFilter" placeholder="Enter Add On Adult Child Price Per Person" value=""> </div>
                                    </div>
                                </div>
                                <div class=col-md-12><span class=pull-right><a class="btn btn-danger ajaxBtnAlter" rel="delete" href="<?= URL::to('admin/tour/deleteDetails/'); ?>" title=remove_field>Remove <i class="fa fa-times ml-10 "></i></a></span></div>
                            </div>
                          </div>
                        </div>

                        <div class="form-group">
                          <label for="nationality" class="label-signin-mystyle">
                            Status <span class="red_asterisk">*</span>
                          </label>
                          <span class="help">e.g. "Enabled, Disabled"</span>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <select class="form-control input-signin-mystyle select2" id="tour_is_active" name="tour_is_active">
                              <option value="" selected="selected" disabled="">- Select Status -</option>
                              <option value="1">Enabled</option>
                              <option value="0">Disabled</option>
                            </select>
                          </div>
                        </div>
                        
                        <div class="form-group">
                              <button class="btn btn-primary btn-cons ajaxFormSubmitAlter pull-right" type="button">Submit</button>
                              
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- END BASIC FORM ELEMENTS-->  
  <script>

    $(document).ready(function() {
        // $("#fileUploader3").checkImageSize({
        //     minWidth: 170,       // Numeric; Pixel value
        //     minHeight: 550,      // Numeric; Pixel value
        //     maxWidth: 182,       // Numeric; Pixel value
        //     maxHeight: 601,      // Numeric; Pixel value
        //     showError: true,     // Boolean; Whether to show error messages
        //     ignoreError: false       // Boolean; Whether to ignore error and let the image pass through
        // });
      $("#speical_offer_type").change(function () {
        var val = $(this).val();
        if (val == 1) {
          $('.myTourDiscount').slideDown();
        }else{
          $('.myTourDiscount').slideUp();
        }
      });

      
      var max_fields      = 6; 
      var wrapper         = $(".amenities_field");
      var add_button      = $(".amenities_field_button");
      var x = 1; 
      $(add_button).click(function(e){
          e.preventDefault();
          $('form.validate').validate();
          if(x < max_fields){
              x++;
              $('.amenities_field').append('<div class="row form-row"> <div class="col-md-6"> <div class="form-row"> <label class="loc_name">Add On Title <span class="red_asterisk">*</span></label> <div class="input-with-icon right controls"> <i class=""></i> <input type="text" id="loc_name'+x+'" required name="add_on_title[]" class="form-control" placeholder="Enter Add On Title" > </div></div></div><div class="col-md-6"> <div class="form-row"> <label class="location">Add On Adult Price Per Person <span class="red_asterisk">*</span></label> <div class="input-with-icon right controls"> <i class=""></i> <input required type="number" id="location'+x+'" name="add_on_adult_price_per_person[]" class="form-control txtboxToFilter" placeholder="Enter Add On Adult Price Per Person" > </div></div></div><div class="col-md-6"> <div class="form-row"> <label class="ad_phone">Add On Adult Child Price Per Person <span class="red_asterisk">*</span></label> <div class="input-with-icon right controls"> <i class=""></i> <input type="number" id="ad_phone'+x+'" required name="add_on_child_price_per_person[]" class="form-control txtboxToFilter" placeholder="Enter Add On Adult Child Price Per Person" > </div></div></div><div class=col-md-12><span class=pull-right><a class="btn btn-danger remove_field "href=# title=remove_field>Remove <i class="fa fa-times ml-10 "></i></a></span></div></div>');
          }else{
              alert("Extra Max Limit Are 5");
          }
      });
      
      $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
          e.preventDefault();
          $(this).parent().parent().parent().remove(); x--;
      });
      // $(function(){
      //     $(".select2").select2();
      // });
      $('.clockpicker').clockpicker({
          autoclose: true,
          twelvehour: true,
      });
      $('.datepicker').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
      });
    });
  </script>

  <script>
  $(document).ready(function() {
    
    $("form.validate").validate({
      rules: {
        tour_title:{
          required: true
        },
        tour_short_description:{
          required: true
        },
        tour_description:{
          required: true
        },
        tour_dinner:{
          required: true
        },
        tour_pick_up:{
          required: true
        },
        tour_live_guide:{
          required: true
        },
        tour_price_per_person:{
          required: true,
          digits: true
        },
        tour_child_price_per_person:{
          required: true,
          digits: true
        },
        tour_shared_price_per_person:{
          required: true,
          digits: true
        },
        tour_child_shared_price_per_person:{
          required: true,
          digits: true
        },
        category_id:{
          required: true
        },
        tour_duration:{
          required: true
        },
        tour_seo_url:{
          required: true
        },
        speical_offer_type:{
          required: true
        },
        discount_percentage:{
          required: true,
          digits: true
        },
        tour_is_active:{
          required: true
        }
      }, 
      messages: {
        tour_price_per_person:{
          required: "This field is required.",
          digits: "Please Insert Digits."
        },
        tour_child_price_per_person:{
          required: "This field is required.",
          digits: "Please Insert Digits."
        },
        tour_shared_price_per_person:{
          required: "This field is required.",
          digits: "Please Insert Digits."
        },
        tour_child_shared_price_per_person:{
          required: "This field is required.",
          digits: "Please Insert Digits."
        },
        tour_title: "This field is required.",
        tour_short_description: "This field is required.",
        tour_description: "This field is required.",
        tour_live_guide: "This field is required.", 
        tour_dinner: "This field is required.",
        tour_pick_up: "This field is required.",
        category_id: "This field is required.",
        tour_duration: "This field is required.",
        tour_seo_url: "This field is required.",
        speical_offer_type: "This field is required.",
        discount_percentage:{
          required: "This field is required.",
          digits: "Please Insert Digits."
        },
        tour_is_active: "This field is required."
      },
      invalidHandler: function (event, validator) {
        //display error alert on form submit    
        },
        errorPlacement: function (label, element) { // render error placement for each input type   
          var icon = $(element).parent('.input-with-icon').children('i');
            icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  

          $('<span class="error"></span>').insertAfter(element).append(label);
          var parent = $(element).parent('.input-with-icon');
          parent.removeClass('success-control').addClass('error-control');  
        },
        highlight: function (element) { // hightlight error inputs
          var icon = $(element).parent('.input-with-icon').children('i');
            icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  

          var parent = $(element).parent();
          parent.removeClass('success-control').addClass('error-control'); 
        },
        unhighlight: function (element) { // revert the change done by hightlight
          var icon = $(element).parent('.input-with-icon').children('i');
      icon.removeClass("fa fa-exclamation").addClass('fa fa-check');

          var parent = $(element).parent();
          parent.removeClass('error-control').addClass('success-control'); 
        },
        success: function (label, element) {
          var icon = $(element).parent('.input-with-icon').children('i');
      icon.removeClass("fa fa-exclamation").addClass('fa fa-check');

          var parent = $(element).parent('.input-with-icon');
          parent.removeClass('error-control').addClass('success-control');

          
        }
        // submitHandler: function (form) {

        // }
      });

    $('.select2', "form.validate").change(function () {
        $('form.validate').validate().element($(this)); //revalidate the chosen dropdown value and show error or success message for the input
    });
    
    $('#fileUploader').fileuploader({
        changeInput: '<div class="fileuploader-input">' +
                          '<div class="fileuploader-input-inner">' +
                            '<img src="<?= URL::asset(''); ?>assets/admin/myplugin/fileuploader/images/fileuploader-dragdrop-icon.png">' +
                          '<h3 class="fileuploader-input-caption"><span>Drag and drop files here</span></h3>' +
                          '<p>or</p>' +
                          '<div class="fileuploader-input-button"><span>Browse Files</span></div>' +
                        '</div>' +
                      '</div>',
        theme: 'dragdrop',
        limit: 20,
        extensions: ['jpg', 'jpeg', 'png'],
        onRemove: function(item) {
          $.post('<?= URL::to('admin/tour/imageSliderDelete'); ?>', {
            file: item.name,
            data: {
              image_file_id:"<?= @$data['tour_id']; ?>",
              file:item.name,
              image_post_file_id:item.data.image_file_id
            }
          });
        },
        captions: {
                feedback: 'Drag and drop files here',
                feedback2: 'Drag and drop files here',
                drop: 'Drag and drop files here'
            },
      });

    $('#fileUploader2').fileuploader({
        changeInput: '<div class="fileuploader-input">' +
                          '<div class="fileuploader-input-inner">' +
                            '<img src="<?= URL::asset(''); ?>assets/admin/myplugin/fileuploader/images/fileuploader-dragdrop-icon.png">' +
                          '<h3 class="fileuploader-input-caption"><span>Drag and drop files here</span></h3>' +
                          '<p>or</p>' +
                          '<div class="fileuploader-input-button"><span>Browse Files</span></div>' +
                        '</div>' +
                      '</div>',
        theme: 'dragdrop',
        limit: 1,
        extensions: ['jpg', 'jpeg', 'png'],
        onRemove: function(item) {
          $.post('<?= URL::to('admin/tour/imageDelete'); ?>', {
            file: item.name,
            data: {
              image2_file_id:"<?= @$data['tour_id']; ?>",
              file:item.name,
              image2_post_file_id:item.data.image2_file_id
            }
          });
        },
        captions: {
                feedback: 'Drag and drop files here',
                feedback2: 'Drag and drop files here',
                drop: 'Drag and drop files here'
            },
      });
      
    $('#fileUploader3').fileuploader({
        changeInput: '<div class="fileuploader-input">' +
                          '<div class="fileuploader-input-inner">' +
                            '<img src="<?= URL::asset(''); ?>assets/admin/myplugin/fileuploader/images/fileuploader-dragdrop-icon.png">' +
                          '<h3 class="fileuploader-input-caption"><span>Drag and drop files here</span></h3>' +
                          '<p>or</p>' +
                          '<div class="fileuploader-input-button"><span>Browse Files</span></div>' +
                        '</div>' +
                      '</div>',
        theme: 'dragdrop',
        limit: 1,
        extensions: ['jpg', 'jpeg', 'png'],
        
        onRemove: function(item) {
          $.post('<?= URL::to('admin/tour/imageVoucherDelete'); ?>', {
            file: item.name,
            data: {
              image2_file_id:"<?= @$data['tour_id']; ?>",
              file:item.name,
              image2_post_file_id:item.data.image2_file_id
            }
          });
        },
        captions: {
                feedback: 'Drag and drop files here',
                feedback2: 'Drag and drop files here',
                drop: 'Drag and drop files here'
            },
      });
      
    

  });
</script>
@endsection
