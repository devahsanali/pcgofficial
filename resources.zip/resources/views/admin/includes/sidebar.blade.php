<!--BEGIN SIDEBAR -->
<div class="page-sidebar" id="main-menu">
    <!-- BEGIN MINI-PROFILE -->
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <ul>
        <li class="{{(Request::route()->getName() == 'admin.home') ? 'active open' : ''}}">
           <a href="{{route('admin.home')}}"> <i class="fa  fa-tachometer" aria-hidden="true"></i>
            <span class="title">Dashboard</span>
          </a> 
        </li>
        <li class="{{(Request::route()->getName() == 'admin.tournament') ? 'active open' : ''}}">
        
           <a href="#"> <i class="fa fa-table" aria-hidden="true"></i>
        
            <span class="title">Tournament</span>
        
            <span class="selected"></span>
        
            <span class="arrow {{(Request::route()->getName() == 'admin.tournament') ? 'open' : ''}}"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-category') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/category/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-category') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/category/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>



        <!-- <li class="<?php echo (@$active == 'admin/add-category' || @$active == 'admin/view-category') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-table" aria-hidden="true"></i>
        
            <span class="title">Category</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-category' || @$active == 'admin/view-category') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-category') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/category/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-category') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/category/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-blog' || @$active == 'admin/view-blog') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-bold" aria-hidden="true"></i>
        
            <span class="title">Blog</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-blog' || @$active == 'admin/view-blog') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-blog') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/blog/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-blog') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/blog/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-gallery' || @$active == 'admin/view-gallery') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-picture-o" aria-hidden="true"></i>
        
            <span class="title">Gallery</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-gallery' || @$active == 'admin/view-gallery') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-gallery') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/gallery/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-gallery') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/gallery/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-service' || @$active == 'admin/view-service') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-cogs" aria-hidden="true"></i>
        
            <span class="title">Service</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-service' || @$active == 'admin/view-service') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-service') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/service/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-service') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/service/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-social_media' || @$active == 'admin/view-social_media') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-globe" aria-hidden="true"></i>
        
            <span class="title">Social Media</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-social_media' || @$active == 'admin/view-social_media') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-social_media') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/social_media/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-social_media') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/social_media/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-newsletter' || @$active == 'admin/view-newsletter') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
        
            <span class="title">Newsletter</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-newsletter' || @$active == 'admin/view-newsletter') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
              <li class="<?php echo (@$active == 'admin/view-newsletter') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/newsletter/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-contact' || @$active == 'admin/view-contact') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-comment" aria-hidden="true"></i>
        
            <span class="title">Contact</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-contact' || @$active == 'admin/view-contact') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-contact') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/contact/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-contact') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/contact/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-rating' || @$active == 'admin/view-rating') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-star" aria-hidden="true"></i>
        
            <span class="title">Rating</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-rating' || @$active == 'admin/view-rating') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-rating') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/rating/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-rating') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/rating/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-booking' || @$active == 'admin/view-booking') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-check-square" aria-hidden="true"></i>
        
            <span class="title">Booking</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-booking' || @$active == 'admin/view-booking') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-booking') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/booking/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-booking') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/booking/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        <li class="<?php echo (@$active == 'admin/add-all_user' || @$active == 'admin/view-all_user') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-users" aria-hidden="true"></i>
        
            <span class="title">User</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-all_user' || @$active == 'admin/view-all_user') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-all_user') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/all_user/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-all_user') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/all_user/view'); ?>"> View </a></li>
        
           </ul>
        
        </li>
        
        
        <li class="<?php echo (@$active == 'admin/add-tour' || @$active == 'admin/view-tour') ? 'active open' : ''; ?>">
           <a href="#"> <i class="fa fa-plane" aria-hidden="true"></i>
            <span class="title">Tour</span>
            <span class="selected"></span>
            <span class="arrow <?php echo (@$active == 'admin/add-tour' || @$active == 'admin/view-tour') ? 'open' : ''; ?>"></span>
          </a> 
           <ul class="sub-menu">
              <li class="<?php echo (@$active == 'admin/add-tour') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/tour/add'); ?>"> Add </a> </li>
              <li class="<?php echo (@$active == 'admin/view-tour') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/tour/view'); ?>"> View </a></li>
           </ul>
        </li>
        
        
        <li class="<?php echo (@$active == 'admin/edit-about_us') ? 'active open' : ''; ?>">
           <a href="<?= URL::to('admin/about_us/edit'); ?>"> <i class="fa fa-user" aria-hidden="true"></i>
            <span class="title">About Us</span>
            <span class="selected"></span>
          </a> 
        </li>
        
        <li class="<?php echo (@$active == 'admin/edit-setting') ? 'active open' : ''; ?>">
           <a href="<?= URL::to('admin/setting/edit'); ?>"> <i class="fa fa-cog" aria-hidden="true"></i>
            <span class="title">Setting</span>
            <span class="selected"></span>
          </a> 
        </li>
        
        
        <li class="<?php echo (@$active == 'admin/add-information' || @$active == 'admin/view-information') ? 'active open' : ''; ?>">
        
           <a href="#"> <i class="fa fa-info-circle" aria-hidden="true"></i>
        
            <span class="title">Information</span>
        
            <span class="selected"></span>
        
            <span class="arrow <?php echo (@$active == 'admin/add-information' || @$active == 'admin/view-information') ? 'open' : ''; ?>"></span>
        
          </a> 
        
           <ul class="sub-menu">
        
              <li class="<?php echo (@$active == 'admin/add-information') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/information/add'); ?>"> Add </a> </li>
        
              <li class="<?php echo (@$active == 'admin/view-information') ? 'active' : ''; ?>"> <a href="<?= URL::to('admin/information/view'); ?>"> View </a></li>
        
           </ul>
         
        </li>-->

    
      </ul>

      <div class="clearfix"></div>

      <!-- END SIDEBAR MENU -->

    </div>

  </div>

  <a href="#" class="scrollup">Scroll</a>

  