@extends('layouts.admin')

@section('content')
@php($page_title ="add")
 <!-- BEGIN PAGE CONTAINER-->
  <div class="page-content">
    <div class="content">
      <ul class="breadcrumb">
        <li>
          <p>Tournament</p>
        </li>
        <li><a href="#" class="active">Add</a> </li>
      </ul>
      <!-- <div class="page-title"> <i class="icon-custom-left"></i>
        <h3></h3>
      </div> -->
    <!-- BEGIN BASIC FORM ELEMENTS-->
        <div class="row">
            <div class="col-md-12">
              <div class="grid simple">
                <div class="grid-title no-border">
                  <h4>Add New <span class="semi-bold">Tournament</span></h4>
                </div>
                <div class="grid-body no-border"> <br>
                  <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                      <form class="ajaxForm validate" action="{{route('admin.tournament.post')}}" method="post" enctype="multipart/form-data">
                      	@csrf
                          <div class="form-group">
                          <label class="form-label">Image</label>
                          <div id="preview"></div>
                          <div class="controls">
                            <?php
                            if (isset($data['tour_id']) && @$data['tour_id'] != null) {
                                $appendedFiles2 = array();
                                $file_path = public_path().$image_upload_dir.'/'.@$data['tour_image'];
                                  if (!is_dir($file_path) && file_exists($file_path)) {
                                    // $current_img = MyCdnUrlImage($image_upload_dir."/".$data['image']);
                                    @$file_details = getimagesize(MyCdnUrlImage($image_upload_dir."/".@$data['tour_image']));
                                    $appendedFiles2[] = array(
                                      "name" => @$data['tour_image'],
                                      "type" => $file_details['mime'],
                                      "size" => filesize($file_path),
                                      "file" => MyCdnUrlImage($image_upload_dir."/". @$data['tour_image']),
                                      "data" => array(
                                        "url" => MyCdnUrlImage($image_upload_dir."/". @$data['tour_image']),
                                        "image_file_id" => $data['tour_id']
                                      )
                                    );
                                  }
                                $appendedFiles2 = json_encode($appendedFiles2);
                            }
                            ?>
                            <input type="file" id="fileUploader" name="image" class="form-control" multiple="multiple" data-fileuploader-files='<?php echo @$appendedFiles2;?>'>
                             
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="form-label">Title <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="title" class="form-control" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="form-label">Type <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <select name="type_id" id="type" class="form-control">
                            	@foreach($types as $type)
                            		<option value="{{$type->id}}">{{$type->title}}</option>
                            	@endforeach
                            </select>
                          </div>
                        </div>

                        <div class="form-group" id="team">
                          <label class="form-label">No of Teams<span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="no_of_teams"  class="form-control no_of_teams" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">No of Players<span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="no_of_players" class="form-control" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>

						 <div class="form-group">
                          <label class="form-label">Platform <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="platform" class="form-control" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>

						<div class="form-group">
                          <label class="form-label">Start Date <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="start_date" class="form-control datepicker" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">End Date <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="end_date" class="form-control datepicker" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="form-label">Entry Charges <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="entry_charges" class="form-control" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>
						
						<div class="form-group">
                          <label class="form-label">Awarding price<span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <input type="text" name="awarding_price" class="form-control" placeholder="Enter Title" value="<?= @$data['tour_title']; ?>">
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <label class="form-label">Short Description <span class="red_asterisk">*</span></label>
                          <div class="input-with-icon right controls">
                            <i class=""></i>
                            <textarea name="description" class="form-control" placeholder="Enter Tour Short Description" ><?= @$data['tour_short_description']; ?></textarea>
                          </div>
                        </div>

                        <div class="form-group">
                              <button class="btn btn-primary btn-cons ajaxFormSubmitAlter pull-right" type="button">Submit</button>      
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- END BASIC FORM ELEMENTS-->  
  <script>

    $(document).ready(function() {
      $('.clockpicker').clockpicker({
          autoclose: true,
          twelvehour: true,
      });
      $('.datepicker').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
      });
    });
  $(document).ready(function() {
    
    $("form.validate").validate({
      rules: {
        title:{
          required: true
        },
        type:{
          required: true
        },
        platform:{
          required: true
        },
        start_date:{
          required: true
        },
        end_date:{
          required: true
        },
        entry_charges:{
          required: true,
          digits: true   
        },
        no_of_players:{
          required: true,
          digits: true
        },
        awarding_price:{
          required: true,
          digits: true
        },
        description:{
          required: true
        },
        no_of_teams: {
          required:{
			   depends: function(element){
			   	   var status = false;
				   if( $('#type').val() == 2){
					   var status = true;
				   }
				   return status;
			   }
		   },
		   digits: true
        }
      }, 
      invalidHandler: function (event, validator) {
        //display error alert on form submit    
        },
        errorPlacement: function (label, element) { 
          // render error placement for each input type   
          var icon = $(element).parent('.input-with-icon').children('i');
            icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  

          $('<span class="error"></span>').insertAfter(element).append(label);
          var parent = $(element).parent('.input-with-icon');
          parent.removeClass('success-control').addClass('error-control');  
        },
        highlight: function (element) { 
          // hightlight error inputs
          var icon = $(element).parent('.input-with-icon').children('i');
          icon.removeClass('fa fa-check').addClass('fa fa-exclamation');  

          var parent = $(element).parent();
          parent.removeClass('success-control').addClass('error-control'); 
        },
        unhighlight: function (element) { 
          // revert the change done by hightlight
          var icon = $(element).parent('.input-with-icon').children('i');
      	  icon.removeClass("fa fa-exclamation").addClass('fa fa-check');

          var parent = $(element).parent();
          parent.removeClass('error-control').addClass('success-control'); 
        },
        success: function (label, element) {
          var icon = $(element).parent('.input-with-icon').children('i');
     	  icon.removeClass("fa fa-exclamation").addClass('fa fa-check');

          var parent = $(element).parent('.input-with-icon');
          parent.removeClass('error-control').addClass('success-control');
        }
        // submitHandler: function (form) {
        // }
      });

    //hide team field
    $('#team').hide();
    //team onchange handler 
    $('#type').on('change', function(){
      (this.value == 1) ? $('#team').hide() : $('#team').show();
       $('form.validate').validate().element($('.no_of_teams'));
	});

    $('#fileUploader').fileuploader({
        changeInput: '<div class="fileuploader-input">' +
                          '<div class="fileuploader-input-inner">' +
                            '<img src="<?= URL::asset('public/assets/admin/myplugin/fileuploader/images/fileuploader-dragdrop-icon.png'); ?>">' +
                          '<h3 class="fileuploader-input-caption"><span>Drag and drop files here</span></h3>' +
                          '<p>or</p>' +
                          '<div class="fileuploader-input-button"><span>Browse Files</span></div>' +
                        '</div>' +
                      '</div>',
        theme: 'dragdrop',
        limit: 10,

        extensions: ['jpg', 'jpeg', 'png'],
        onRemove: function(item) {
          /*$.post('<?= URL::to('admin/tour/imageSliderDelete'); ?>', {
            file: item.name,
            data: {
              image_file_id:"<?= @$data['tour_id']; ?>",
              file:item.name,
              image_post_file_id:item.data.image_file_id
            }
          });*/
        },
        captions: {
                feedback: 'Drag and drop files here',
                feedback2: 'Drag and drop files here',
                drop: 'Drag and drop files here'
            },
      });

    

  });
</script>
@endsection
