@extends('layouts.admin')

@section('content')
 <div class="page-content">
    <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
    <div class="content">
      <ul class="breadcrumb">
        <li>
          <p>Tournament</p>
        </li>
        <li><a href="#" class="active">View</a> </li>
      </ul>
     <!--  <div class="page-title"> <i class="icon-custom-left"></i>
       <h3>View All - <span class="semi-bold"><?= (isset($page_heading))?$page_heading:''; ?></span></h3>
     </div> -->
      <div class="row-fluid">
        <div class="span12">
          <div class="grid simple ">
            <div class="grid-title">
              <h4>View All </span></h4>
              <div class="col-12 pull-right">
                  <form method="post" action="">
                      <select class="status" name="status">
                          <option value="" selected="selected" disabled="">- Select Status -</option>
                          <option value="4" <?= (@$status == 4)?'selected':''; ?>>All</option>
                          <option value="0" <?= (@$status == 0)?'selected':''; ?>>Cancelled</option>
                          <option value="1" <?= (@$status == 1)?'selected':''; ?>>Confirmed</option>
                          <option value="2" <?= (@$status == 2)?'selected':''; ?>>Void</option>
                          <option value="3" <?= (@$status == 3)?'selected':''; ?>>On Hold</option>
                          
                          
                      </select>
                  </form>
              </div>
            </div>
            <div class="grid-body table-responsive" style="overflow-x: scroll;">
              <table class="table" id="example3" >
                <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th>Tour Name</th>
                    <th>Order No.</th>
                    <th>Booking Name</th>
                    <th>Booking Email</th>
                    <th>Contact</th>
                    <th>Address</th>
                    <th>Pickup Address</th>
                    <th>Pickup Date</th>
                    <th>No.Adult</th>
                    <th>No.Child </th>
                    <th>No.Exclusive </th>
                    <th>Total</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Created Date</th>
                    <th width="200px">Action</th>
                  </tr>
                </thead>
                <tbody>
    
                  <tr class="">
                    <td>10</td>
                    <td>
                      <a href="#" class="myModalBtn" data-id="" data-path="admin/tour/detail">ac</a>
                    </td>
                    <td>505</td>
                    <td>new booking</td>
                    <td>abc@gmail.com</td>
                    <td>booking_phone</td>
                    <td>booking_address</td>
                    <td>
                        
                                  bookingPickupLocationData 
                        
                    </td>
                    <td>booking_pickup_date</td>
                    <td>booking_no_of_adult</td>
                    <td>booking_no_of_child</td>
                    <td>booking_exclusive_quantity</td>
                    <td>5</td>
                    <td>
                     
                        bookingTransferData 
                      <span class="label label-success">5</span>
                    
                    </td>
                    <td>
                        bookingStatusData
                        
                      <span class="label label-success">status</span>
                    </td>
                    <td>booking_gmt_create_date</td>
                    <td class="">
                      <a href="#" class="btn-primary btn btn-sm myModalBtn" data-id="" data-path=""><i class="fa fa-eye"></i></a>

                      <div class="btn-group ">
                        <button class="btn btn-white btn-demo-space"> <i class="fa fa-cog"></i></button>
                        <button class="btn btn-white dropdown-toggle btn-demo-space" data-toggle="dropdown"> <span class="caret"></span> </button>
                        <ul class="dropdown-menu">
                          <li><a href="" class="ajaxBtnAlter">Cancelled</a></li>
                        </ul>
                      </div>
                    <a  class="btn-primary btn btn-sm" target='_blank' href='' ><i class="fa fa-paste"></i></a>
                    <a  class="btn-primary btn btn-sm" target='_blank' href='' ><i class="fa fa-download"></i></a>
                    <a href="" class="btn-warning btn btn-sm"><i class="fa fa-pencil"></i></a>
                      
                      <a href="" rel="delete" class="ajaxBtnAlter btn-danger btn btn-sm"><i class="fa fa-times"></i></a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
        $( ".status" ).change(function() {
          $( "form" ).submit();
        });
    </script>
    <!-- Modal -->
    @include('admin.includes.modal')
    <!-- /.modal -->

  </div>
@endsection
