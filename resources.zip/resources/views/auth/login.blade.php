@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row login-container">
        <div class="col-md-offset-3 col-md-6">
            <div class="text-center">
                <img src="<?= URL::asset('') ?>assets/admin/img/luxury-adventures_logo.svg" class="logo img-responsive" alt="">
            </div>
            <h2>Sign in</h2>
            <form method="POST" action="{{ route('login') }}">
                @csrf

                <div class="row">
                    <div class="form-group col-md-12">
                        <label class="form-label">E-mail</label>
                        <div class="controls">
                            <div class="input-with-icon right">
                                <i class=""></i>
                                <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Enter Email"> 
                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span> 
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-12">
                        <label class="form-label">Password</label>
                        <span class="help"></span>
                        <div class="controls">
                            <div class="input-with-icon right">
                                <i class=""></i>
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="Enter Password"> 
                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                         <strong>{{ $message }}</strong>
                                    </span> 
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <button class="btn btn-primary btn-cons pull-right" type="submit">Submit</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>
@endsection