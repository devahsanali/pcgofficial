<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Admin Panel <?= (isset($title) && $title != '' )?'| '.$title:''; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />
<link rel="shortcut icon" type="image/x-icon" href="<?= base_url();?>assets/frontend/images/favicon/favicon.png" />
<!-- BEGIN CORE CSS FRAMEWORK -->
<link href="<?= base_url(); ?>assets/admin/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="<?= base_url(); ?>assets/admin/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/animate.min.css" rel="stylesheet" type="text/css"/>
<!-- END CORE CSS FRAMEWORK -->
<!-- BEGIN CSS TEMPLATE -->
<link href="<?= base_url(); ?>assets/admin/css/style.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
<!-- END CSS TEMPLATE -->

<!-- sweetalert -->
<script src="<?= base_url(); ?>assets/admin/myplugin/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/sweetalert2/dist/sweetalert2.min.js"></script>
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/sweetalert2/dist/sweetalert2.min.css">

<!-- Start My plugin validation -->
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/validation/toastr.css">
<!-- end My plugin validation -->

<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/validation/jquery-validate/css/jquery.validate.css">
<script type="text/javascript" src="<?= base_url(); ?>assets/admin/js/jquery.min.js"></script>

<script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery-validate/js/jquery.validate.js"></script>

<!-- start My plugin loader -->
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/loader/css/main.css">
<!-- end My plugin loader -->
<!-- user-timezone-javascript -->
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/jstz-1.0.4.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/moment.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/moment-timezone.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/moment-timezone-data.js"></script>

</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="error-body no-top">
<div class="loading-wrapper">
    <div class="loading"></div>
</div>
@yield('content')
<!-- END CONTAINER -->
<!-- BEGIN CORE JS FRAMEWORK-->

<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/js/login.js" type="text/javascript"></script>
<!-- BEGIN CORE TEMPLATE JS -->
<!-- END CORE TEMPLATE JS -->

<!-- Start My plugin validation -->
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/custom.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery.browser.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery.form.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/toastr.js"></script>
<!-- end My plugin validation -->

<!-- start My plugin loader -->
<script src="<?= base_url(); ?>assets/admin/myplugin/loader/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/loader/js/loader.js"></script>
<!-- end My plugin loader -->


<script type="text/javascript">
    jQuery(document).ready(function() {
        var tz = jstz.determine();
        var timezone = tz.name();
        $.ajax({
            url: "<?= URL::to('') ?>/admin/user/date_default_timezone_set/?timezone="+timezone,
            dataType: "json",
            error: function(jqXHR, textStatus, errorThrown)
            {
                console.log("Request not completed.Please try Again");
            },
            success: function(data) {
                console.log(data);
            }
        });
    });
</script>
</body>
</html>