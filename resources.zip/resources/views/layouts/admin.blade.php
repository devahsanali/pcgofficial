<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>Admin Panel <?= (isset($title) && $title != '' )?'| '.$title:''; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />
<link href="https://fonts.googleapis.com/css?family=Playfair+Display:900|Source+Sans+Pro:300,400,600,900&amp;display=swap" rel="stylesheet">
<link rel="icon" href="<?= base_url();?>assets/frontend/images/favicon/favicon.png" type="image/x-icon" />

<!-- BEGIN Form element PLUGIN CSS -->
<!-- <link href="<?= base_url(); ?>assets/admin/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="<?= base_url(); ?>assets/admin/plugins/bootstrap-tag/bootstrap-tagsinput.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>assets/admin/plugins/bootstrap-timepicker/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url(); ?>assets/admin/plugins/ios-switch/ios7-switch.css" rel="stylesheet" type="text/css" media="screen">
<link href="<?= base_url(); ?>assets/admin/plugins/bootstrap-select2/select2.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="<?= base_url(); ?>assets/admin/plugins/boostrap-clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css" media="screen"/> -->

<link href="<?= base_url(); ?>assets/admin/plugins/dropzone/css/dropzone.css" rel="stylesheet" type="text/css"/>
<!-- sweetalert -->
<script src="<?= base_url(); ?>assets/admin/myplugin/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/sweetalert2/dist/sweetalert2.min.js"></script>
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/sweetalert2/dist/sweetalert2.min.css">


 
<!-- END Form element PLUGIN CSS -->

<!-- BEGIN datatable PLUGIN CSS -->
  <link href="<?= base_url(); ?>assets/admin/plugins/jquery-datatable/css/jquery.dataTables.css" rel="stylesheet" type="text/css"/>
  <link href="<?= base_url(); ?>assets/admin/plugins/datatables-responsive/css/datatables.responsive.css" rel="stylesheet" type="text/css" media="screen"/>
<!-- END datatable PLUGIN CSS -->



<!-- <link href="<?= base_url(); ?>assets/admin/plugins/jquery-metrojs/MetroJs.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/plugins/shape-hover/css/demo.css" />
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/plugins/shape-hover/css/component.css" />
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/plugins/owl-carousel/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/admin/plugins/owl-carousel/owl.theme.css" />
<link href="<?= base_url(); ?>assets/admin/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="<?= base_url(); ?>assets/admin/plugins/jquery-slider/css/jquery.sidr.light.css" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/jquery-ricksaw-chart/css/rickshaw.css" type="text/css" media="screen" >
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/Mapplic/mapplic/mapplic.css" type="text/css" media="screen" > -->
<!-- BEGIN CORE CSS FRAMEWORK -->
<link href="<?= base_url(); ?>assets/admin/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<!-- END CORE CSS FRAMEWORK -->

<!-- BEGIN CSS TEMPLATE -->
<link href="<?= base_url(); ?>assets/admin/css/style.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
<link href="<?= base_url(); ?>assets/admin/css/magic_space.css" rel="stylesheet" type="text/css"/>
<!-- END CSS TEMPLATE -->


<!-- Start My plugin validation -->
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/validation/toastr.css">
<!-- end My plugin validation -->

<!-- start My plugin loader -->
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/loader/css/main.css">
<!-- end My plugin loader -->
 <script type="text/javascript" src="<?= base_url(); ?>assets/admin/js/jquery.min.js"></script> 

<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/validation/jquery-validate/css/jquery.validate.css">

<script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery-validate/js/jquery.validate.js"></script>


<!-- fileuploader -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/fileuploader/css/jquery.fileuploader.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/admin/myplugin/fileuploader/css/jquery.fileuploader-theme-dragdrop.css">
    <script src="<?= base_url(); ?>assets/admin/myplugin/fileuploader/js/jquery.fileuploader.js"></script>
<!-- user-timezone-javascript -->
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/jstz-1.0.4.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/moment.min.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/moment-timezone.js"></script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/admin/myplugin/user-timezone-javascript/js/moment-timezone-data.js"></script>

    <link href="<?= base_url(); ?>assets/admin/css/custom.css" rel="stylesheet" type="text/css"/>

    
<?php
if (@$uri == "dashboard") {
?>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/series-label.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
<?php
}
?>

</head>
<!-- END HEAD -->
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
      <br>
      <i class="fa fa-credit-card fa-7x"></i>
      <h4 id="myModalLabel" class="semi-bold">Confirm Submition.</h4>
      <p class="no-margin">Are you sure you wanna continue.? </p>
      <br>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      <button type="button" class="btn btn-primary">Save changes</button>
    </div>
  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- BEGIN BODY -->
<body class="">
<!-- BEGIN BODY -->
<body class="error-body no-top">
<!-- <div class="loading-wrapper">
    <div class="loading"></div>
</div> -->

<!-- BEGIN HEADER -->
<div class="header navbar navbar-inverse ">
  <!-- BEGIN TOP NAVIGATION BAR -->
  <div class="navbar-inner">
    <div class="header-seperation">
      <ul class="nav pull-left notifcation-center" id="main-menu-toggle-wrapper" style="display:none">
        <li class="dropdown"> <a id="main-menu-toggle" href="#main-menu"  class="" >
          <div class="iconset top-menu-toggle-white"></div>
          </a> </li>
      </ul>
      <!-- BEGIN LOGO -->
      <a href="<?= URL::to('admin/dashboard'); ?>"><img src="<?= base_url(); ?>assets/admin/img/luxury-adventures_logo.svg" class="logo" alt=""  data-src="<?= base_url(); ?>assets/admin/img/luxury-adventures_logo.svg" data-src-retina="<?= base_url(); ?>assets/admin/img/luxury-adventures_logo.svg" width="156" height=""/></a>
      <!-- END LOGO -->
      <ul class="nav pull-right notifcation-center">
        <li class="dropdown" id="header_task_bar"> <a href="<?= URL::to('admin/dashboard'); ?>" class="dropdown-toggle active" data-toggle="">
          <div class="iconset top-home"></div>
          </a> </li>

        <!-- <li class="dropdown" id="portrait-chat-toggler" style="display:none"> <a href="#sidr" class="chat-menu-toggle"> -->
          <!-- <div class="iconset top-chat-white "></div> -->
          <!-- </a> </li> -->
      </ul>
      <div class="pull-right my-cog-log-style">
        <ul class="nav quick-section ">
          <li class="quicklinks"> <a data-toggle="dropdown" class="dropdown-toggle  pull-right " href="#" id="user-options">
            <div class="iconset top-settings-dark "></div>
            </a>
            <ul class="dropdown-menu  pull-right" role="menu" aria-labelledby="user-options">
              <li><a href="{{route('admin.register')}}"> Create Account</a> </li>
              <li><a href="<?= URL::to('admin/my_account/update'); ?>"> My Account</a> </li>
              <li class="divider"></li>
              <li><a href="<?= URL::to('/logout'); ?>"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Log Out</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
    <!-- END RESPONSIVE MENU TOGGLER -->
    <div class="header-quick-nav" >
      <!-- BEGIN TOP NAVIGATION MENU -->
      <div class="pull-left">
        <ul class="nav quick-section">
          <li class="quicklinks"> <a href="#" class="" id="layout-condensed-toggle" >
            <div class="iconset top-menu-toggle-dark"></div>
            </a> </li>
        </ul>
      </div>
      <!-- END TOP NAVIGATION MENU -->
      <!-- BEGIN CHAT TOGGLER -->
      <div class="pull-right">
        <style type="text/css">
          .header .chat-toggler{
            top: 12px;
             margin-right: 0px; 
            min-width:auto;
          }
        </style>
        <div class="chat-toggler">
          <div class="user-details">
            <div class="username"><span class="bold">Admin</span> </div>
          </div>
        </div>

        <ul class="nav quick-section ">
          <li class="quicklinks"> <a data-toggle="dropdown" class="dropdown-toggle  pull-right " href="#" id="user-options">
            <div class="iconset top-settings-dark "></div>
            </a>
            <ul class="dropdown-menu  pull-right" role="menu" aria-labelledby="user-options">
              <li><a href="{{route('admin.register')}}"> Create Account</a> </li>
              <li><a href="<?= URL::to('admin/my_account/update'); ?>"> My Account</a> </li>
              <li class="divider"></li>
              <li><a href="<?= URL::to('/logout'); ?>"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Log Out</a></li>
            </ul>
          </li>
        </ul>
      </div>
      <!-- END CHAT TOGGLER -->
    </div>
    <!-- END TOP NAVIGATION MENU -->
  </div>
  <!-- END TOP NAVIGATION BAR -->
</div>
<!-- END HEADER -->

<!-- BEGIN CONTAINER -->
<div class="page-container row-fluid">
	@include('admin.includes.sidebar')
	@yield('content')

</div>

<!-- <script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery-validate/js/jquery-3.1.1.js"></script> -->
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/boostrapv3/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/breakpoints.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-lazyload/jquery.lazyload.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<!-- END CORE JS FRAMEWORK -->
<!-- BEGIN PAGE LEVEL JS -->
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-slider/jquery.sidr.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-ricksaw-chart/js/raphael-min.js"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-ricksaw-chart/js/d3.v2.js"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-ricksaw-chart/js/rickshaw.min.js"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-sparkline/jquery-sparkline.js"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/skycons/skycons.js"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/owl-carousel/owl.carousel.min.js" type="text/javascript"></script>
<!-- <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script> -->
<!-- <script src="<?= base_url(); ?>assets/admin/plugins/jquery-gmap/gmaps.js" type="text/javascript"></script> -->
<script src="<?= base_url(); ?>assets/admin/plugins/Mapplic/js/jquery.easing.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/Mapplic/js/jquery.mousewheel.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/Mapplic/js/hammer.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/Mapplic/mapplic/mapplic.js" type="text/javascript"></script>
    
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-flot/jquery.flot.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-flot/jquery.flot.resize.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-metrojs/MetroJs.min.js" type="text/javascript" ></script>
<!-- END PAGE LEVEL PLUGINS -->
<script src="<?= base_url(); ?>assets/admin/plugins/morris/morris.js" type="text/javascript"></script>  
<script src="<?= base_url(); ?>assets/admin/plugins/morris/morris.min.js" type="text/javascript"></script>  

<!-- BEGIN Form element PAGE LEVEL PLUGINS -->
<!-- <script src="<?= base_url(); ?>assets/admin/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script>  -->
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-inputmask/jquery.inputmask.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-autonumeric/autoNumeric.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/ios-switch/ios7-switch.js" type="text/javascript"></script>
<!-- <script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script> -->
<!-- <script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script> -->
<!-- <script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script> -->
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-tag/bootstrap-tagsinput.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/boostrap-clockpicker/bootstrap-clockpicker.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/dropzone/dropzone.min.js" type="text/javascript"></script>
<!-- <script src="<?= base_url(); ?>assets/admin/js/form_elements.js" type="text/javascript"></script> -->
<!-- END Form element PAGE LEVEL PLUGINS -->

<!-- BEGIN datatable PAGE LEVEL JS -->
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>    
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap-select2/select2.min.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-datatable/js/jquery.dataTables.min.js" type="text/javascript" ></script>
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-datatable/extra/js/dataTables.tableTools.min.js" type="text/javascript" ></script>
<script type="text/javascript" src="<?= base_url(); ?>assets/admin/plugins/datatables-responsive/js/datatables.responsive.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>assets/admin/plugins/datatables-responsive/js/lodash.min.js"></script>
<script src="<?= base_url(); ?>assets/admin/js/datatables.js" type="text/javascript"></script>

<!-- END datatable PAGE LEVEL PLUGINS -->



<!-- BEGIN CORE TEMPLATE JS -->
<script src="<?= base_url(); ?>assets/admin/js/core.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/js/chat.js" type="text/javascript"></script>
<script src="<?= base_url(); ?>assets/admin/js/demo.js" type="text/javascript"></script>
<!-- <script src="<?= base_url(); ?>assets/admin/js/dashboard_v2.js" type="text/javascript"></script> -->



<!-- Start My plugin validation -->
<!-- <script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery_validation_engine/jquery.validationEngine.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery_validation_engine/jquery.validationEngine-en.js"></script>-->
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/custom.js"></script>
<!-- <script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery.checkImageSize.js"></script>-->
<!-- <script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery.checkImageSize.min.js"></script>-->
 <script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery.browser.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/jquery.form.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/validation/toastr.js"></script> 

<!-- <script src="<?= base_url(); ?>assets/admin/myplugin/jquery-validate/js/jquery-3.1.1.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/jquery-validate/js/jquery.validate.js"></script> -->


<!-- end My plugin validation -->

<!-- start My plugin loader -->
<script src="<?= base_url(); ?>assets/admin/myplugin/loader/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
<script src="<?= base_url(); ?>assets/admin/myplugin/loader/js/loader.js"></script>
<!-- <script src="<?= base_url(); ?>assets/ckeditor/ckeditor.js"></script>
<script src="<?= base_url(); ?>assets/ckeditor/sample.js"></script> -->

<!-- end My plugin loader -->

</body>
</html>
